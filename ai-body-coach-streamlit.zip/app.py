
import json
from typing import List
import streamlit as st
from models import GoalInput
from analysis import analyze_image, aggregate_findings
from plan import build_program

st.set_page_config(page_title="AI Body Coach", page_icon="💪", layout="centered")

st.title("💪 AI Body Coach (MVP)")
st.write("Analyze your physique photos and get a targeted program — all locally.")

with st.expander("Disclaimer"):
    st.write("This app provides heuristic, educational advice based on photos and general training principles. It does not provide medical advice. Outcomes depend on training, nutrition, rest, and individual differences.")

st.header("1) Goals & Constraints")
col1, col2 = st.columns(2)
goals_text = col1.text_input("Goals (comma‑separated)", value="hypertrophy, symmetry")
days = col2.number_input("Days per week", min_value=2, max_value=6, value=5, step=1)
mins = col1.number_input("Session minutes", min_value=40, max_value=120, value=70, step=5)
equip_text = col2.text_input("Equipment (comma‑separated)", value="barbell,dumbbell,cables,machines")
months = col1.number_input("Training age (months)", min_value=0, max_value=200, value=18, step=1)
injuries_text = col2.text_input("Injuries (optional, comma‑separated)", value="")

g = GoalInput(
    goals=[s.strip() for s in goals_text.split(",") if s.strip()],
    days_per_week=int(days),
    session_minutes=int(mins),
    equipment=[s.strip() for s in equip_text.split(",") if s.strip()],
    training_age_months=int(months),
    injuries=[s.strip() for s in injuries_text.split(",") if s.strip()]
)

st.header("2) Upload Photos")
st.caption("TIP: full‑body frame, upright posture, good lighting. Start with **front / side / back**.")
uploaded = st.file_uploader("Upload 3–8 images (JPG/PNG)", accept_multiple_files=True, type=["jpg","jpeg","png"])

pose_labels_default = ["front","side","back"]
pose_labels = []
if uploaded:
    st.write("Assign a pose label for each image:")
    for i, f in enumerate(uploaded):
        pose = st.selectbox(f"Image {i+1}: {f.name}", options=["front","side","back","fdb","bdb","abs_thigh","other"],
                            index=min(i, len(pose_labels_default)-1))
        pose_labels.append(pose)

run = st.button("Analyze & Build Plan", type="primary", disabled=not uploaded)

if run and uploaded:
    with st.spinner("Running pose analysis..."):
        per_pose = []
        for f in uploaded:
            try:
                res = analyze_image(f)
            except Exception as e:
                res = {"ok": False, "message": str(e), "ratios": {}, "symmetry": {}}
            per_pose.append(res)

        agg = aggregate_findings(per_pose)

    st.header("3) Analysis")
    st.subheader("Ratios")
    if agg.get("ratios"):
        st.json(agg["ratios"])
    else:
        st.write("No ratios computed. Ensure full body is visible.")

    st.subheader("Symmetry")
    if agg.get("symmetry"):
        st.json(agg["symmetry"])
    else:
        st.write("No symmetry metrics.")

    st.subheader("Weak points (heuristic)")
    st.write(", ".join(agg.get("weak_points", [])) or "n/a")

    st.subheader("Genetic leans (visual tendencies)")
    st.write(", ".join(agg.get("genetic_leans", [])) or "n/a")

    st.caption(f"Confidence: {json.dumps(agg.get('confidence', {}))}")

    st.header("4) Program")
    prog = build_program(days_per_week=g.days_per_week, emphasis=agg.get("weak_points", []))

    st.write(f"**Split:** {prog.split}")
    st.write(f"**Emphasis:** {', '.join(prog.emphasis) if prog.emphasis else 'n/a'}")
    st.subheader("Days")
    for day in prog.days:
        st.markdown(f"**{day.name}**")
        for ex in day.exercises:
            st.write(f"- {ex['name']} — {ex['sets']}×{ex['reps']} (RIR {ex['rir']})")

    st.subheader("Progression")
    st.write(prog.progression)

    st.info("Future physique visualization is not included in this MVP. It can be added later as an optional image‑to‑image feature (e.g., SDXL + ControlNet).")
