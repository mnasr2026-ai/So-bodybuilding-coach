
from pydantic import BaseModel, Field
from typing import List, Dict, Optional

class GoalInput(BaseModel):
    goals: List[str] = Field(default_factory=list)  # e.g. ["hypertrophy","symmetry"]
    days_per_week: int = 4
    session_minutes: int = 60
    equipment: List[str] = Field(default_factory=list)  # ["barbell","dumbbell","machines"]
    training_age_months: int = 6
    injuries: List[str] = Field(default_factory=list)
    notes: Optional[str] = None

class AnalysisResult(BaseModel):
    ratios: Dict[str, float]
    symmetry: Dict[str, float]
    weak_points: List[str]
    genetic_leans: List[str]
    confidence: Dict[str, float]

class ProgramDay(BaseModel):
    name: str
    exercises: List[Dict]

class Program(BaseModel):
    split: str
    emphasis: List[str]
    days: List[ProgramDay]
    progression: str
