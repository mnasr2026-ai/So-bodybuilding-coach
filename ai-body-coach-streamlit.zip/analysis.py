
from typing import Dict, List, Tuple
import numpy as np
from PIL import Image
import mediapipe as mp

mp_pose = mp.solutions.pose
LMS = mp_pose.PoseLandmark

def _landmark_xy(landmark, w, h) -> Tuple[float, float]:
    return landmark.x * w, landmark.y * h

def analyze_image(image) -> Dict:
    """
    Accepts a PIL Image or path-like, returns basic pose metrics.
    """
    if not isinstance(image, Image.Image):
        img = Image.open(image).convert("RGB")
    else:
        img = image.convert("RGB")
    w, h = img.size
    img_np = np.array(img)

    with mp_pose.Pose(static_image_mode=True, model_complexity=1, enable_segmentation=False) as pose:
        res = pose.process(img_np)

    if not res.pose_landmarks:
        return {"ok": False, "message": "No pose detected", "ratios": {}, "symmetry": {}}

    kp = res.pose_landmarks.landmark

    def dist(a, b):
        return ((a[0]-b[0])**2 + (a[1]-b[1])**2) ** 0.5

    # Key landmarks
    ls = _landmark_xy(kp[LMS.LEFT_SHOULDER.value], w, h)
    rs = _landmark_xy(kp[LMS.RIGHT_SHOULDER.value], w, h)
    lh = _landmark_xy(kp[LMS.LEFT_HIP.value], w, h)
    rh = _landmark_xy(kp[LMS.RIGHT_HIP.value], w, h)
    le = _landmark_xy(kp[LMS.LEFT_ELBOW.value], w, h)
    re = _landmark_xy(kp[LMS.RIGHT_ELBOW.value], w, h)
    lw = _landmark_xy(kp[LMS.LEFT_WRIST.value], w, h)
    rw = _landmark_xy(kp[LMS.RIGHT_WRIST.value], w, h)

    shoulder_w = dist(ls, rs) + 1e-6
    hip_w = dist(lh, rh) + 1e-6
    shoulder_to_hip = shoulder_w / hip_w

    left_arm = dist(ls, le) + dist(le, lw)
    right_arm = dist(rs, re) + dist(re, rw)
    arm_sym = 1.0 - abs(left_arm - right_arm) / ((left_arm + right_arm)/2 + 1e-6)
    arm_sym = max(0.0, min(1.0, arm_sym))

    ratios = {"shoulder_to_hip": round(float(shoulder_to_hip), 3)}
    symmetry = {"arm_symmetry": round(float(arm_sym), 3)}

    return {"ok": True, "ratios": ratios, "symmetry": symmetry}

def aggregate_findings(per_pose: List[Dict]) -> Dict:
    import numpy as np
    ratios_all, sym_all = {}, {}
    for res in per_pose:
        for k, v in res.get("ratios", {}).items():
            ratios_all.setdefault(k, []).append(v)
        for k, v in res.get("symmetry", {}).items():
            sym_all.setdefault(k, []).append(v)

    ratios_avg = {k: float(np.mean(v)) for k, v in ratios_all.items()} if ratios_all else {}
    sym_avg = {k: float(np.mean(v)) for k, v in sym_all.items()} if sym_all else {}

    weak_points, genetic_leans = [], []

    sh_to_hip = ratios_avg.get("shoulder_to_hip")
    if sh_to_hip is not None:
        if sh_to_hip < 1.20:
            weak_points.append("lateral_delts")
            genetic_leans.append("narrower_clavicles")
        elif sh_to_hip > 1.35:
            genetic_leans.append("wide_clavicles")

    arm_sym = sym_avg.get("arm_symmetry")
    if arm_sym is not None and arm_sym < 0.90:
        weak_points.append("unilateral_arms")

    if not weak_points:
        weak_points = ["rear_delts", "calves"]

    confidence = {
        "ratios": 0.75 if sh_to_hip is not None else 0.5,
        "weak_points": 0.65
    }

    return {
        "ratios": {k: round(v, 3) for k, v in ratios_avg.items()},
        "symmetry": {k: round(v, 3) for k, v in sym_avg.items()},
        "weak_points": sorted(list(set(weak_points))),
        "genetic_leans": sorted(list(set(genetic_leans))),
        "confidence": confidence
    }
