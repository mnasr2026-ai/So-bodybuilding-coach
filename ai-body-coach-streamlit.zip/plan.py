
from typing import List, Dict
from models import Program, ProgramDay

BASE_SETS = {
    "chest": (10, 14),
    "back": (12, 16),
    "delts": (10, 16),
    "biceps": (8, 12),
    "triceps": (8, 12),
    "quads": (10, 16),
    "hams": (8, 12),
    "calves": (8, 12),
}

EMPHASIS_MAP = {
    "lateral_delts": {"delts": 0.35},
    "rear_delts":    {"delts": 0.35},
    "calves":        {"calves": 0.35},
    "unilateral_arms": {"biceps": 0.2, "triceps": 0.2},
}

def pick_split(days: int) -> str:
    if days <= 3: return "Full Body x3"
    if days == 4: return "Upper/Lower x4"
    if days == 5: return "ULPPL x5"
    return "PPL x6"

def weekly_sets(base_sets: Dict[str, tuple], emphasis: List[str]) -> Dict[str, int]:
    out = {k: int(sum(v)/2) for k, v in base_sets.items()}  # midpoint
    for e in emphasis:
        if e in EMPHASIS_MAP:
            for k, bump in EMPHASIS_MAP[e].items():
                out[k] = int(out.get(k, 10) * (1 + bump))
    for k in out:
        lo, hi = base_sets.get(k, (8, 16))
        out[k] = max(lo, min(hi+6, out[k]))
    return out

def make_day(name: str, exs: List[Dict]) -> ProgramDay:
    return ProgramDay(name=name, exercises=exs)

def build_program(days_per_week: int, emphasis: List[str]) -> Program:
    split = pick_split(days_per_week)

    push = [
        {"name":"Incline DB Press","sets":3,"reps":"6-10","rir":1},
        {"name":"Machine Press","sets":2,"reps":"8-12","rir":1},
        {"name":"Cable Lateral Raise (stretched)","sets":4 if "lateral_delts" in emphasis else 2,"reps":"12-20","rir":2},
        {"name":"Overhead Cable Extension","sets":3,"reps":"10-15","rir":1},
    ]
    pull = [
        {"name":"Chest-Supported Row","sets":3,"reps":"6-10","rir":1},
        {"name":"Lat Pulldown (neutral)","sets":3,"reps":"8-12","rir":1},
        {"name":"Reverse Pec Deck","sets":4 if "rear_delts" in emphasis else 2,"reps":"12-20","rir":2},
        {"name":"Alternating DB Curl (weak side +1 set if unilateral_arms)","sets":3,"reps":"8-12","rir":1},
    ]
    legs = [
        {"name":"Hack Squat or Heels-Elevated Squat","sets":3,"reps":"6-10","rir":1},
        {"name":"Romanian Deadlift","sets":3,"reps":"6-10","rir":1},
        {"name":"Leg Press (narrow/low for quad sweep)","sets":2,"reps":"10-15","rir":1},
        {"name":"Calf Raise (every session small dose)","sets":3 if "calves" in emphasis else 2,"reps":"10-15","rir":1},
    ]

    days = []
    if split.startswith("Full Body"):
        days = [
            make_day("Full A", push[:2] + pull[:2] + legs[2:]),
            make_day("Full B", pull[:2] + legs[:2] + push[2:]),
            make_day("Full C", legs[:2] + push[:2] + pull[2:]),
        ]
    elif split.startswith("Upper/Lower"):
        days = [
            make_day("Upper", push[:2] + pull[:2] + [pull[2]]),
            make_day("Lower", legs),
            make_day("Upper 2", pull[:2] + push[:2] + [push[2]]),
            make_day("Lower 2", legs),
        ]
    elif split.startswith("ULPPL"):
        days = [
            make_day("Upper", push[:2] + pull[:2] + [push[2]]),
            make_day("Lower", legs),
            make_day("Push", push),
            make_day("Pull", pull),
            make_day("Legs", legs),
        ]
    else:  # PPL x6
        days = [
            make_day("Push", push),
            make_day("Pull", pull),
            make_day("Legs", legs),
            make_day("Push 2", push),
            make_day("Pull 2", pull),
            make_day("Legs 2", legs),
        ]

    return Program(
        split=split,
        emphasis=emphasis,
        days=days,
        progression="Double progression. Add reps until top of range, then +2.5–5% load. Week 4 deload at 60–70% volume."
    )
