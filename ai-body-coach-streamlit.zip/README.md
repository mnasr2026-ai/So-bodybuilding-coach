
# AI Body Coach (Streamlit MVP)

A one-command local app that:
- Asks for your goals and constraints
- Lets you upload front/side/back photos
- Runs pose analysis (MediaPipe) to compute ratios & symmetry
- Flags likely weak points (e.g., lateral delts, unilateral arms)
- Auto-generates a weekly training plan (split, exercises, sets/reps, progression)

## Quick Start (VS Code or Terminal)
1. **Create and activate a virtual environment** (recommended)
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   ```

2. **Install requirements**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the app**
   ```bash
   streamlit run app.py
   ```

4. Your browser will open automatically. If not, open the URL shown in the terminal (usually http://localhost:8501).

## Notes
- All photos are processed locally and not uploaded anywhere.
- MediaPipe Pose works best with upright, full-body shots in good lighting (front, side, back).
- This is an MVP with heuristic rules; upgrade models and heuristics as you iterate.
- The "future physique" render is not included in this bundle. You can add a diffusion-based renderer later.
